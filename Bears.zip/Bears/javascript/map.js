var map = L.map('map', {});

// PAINEIS
map.createPane('pane_0').style.zIndex = 499;
map.createPane('pane_1').style.zIndex = 498;
map.createPane('pane_2').style.zIndex = 497;
map.createPane('pane_3').style.zIndex = 496;
map.createPane('pane_4').style.zIndex = 495;
map.createPane('pane_5').style.zIndex = 494;
map.createPane('pane_6').style.zIndex = 493;
map.createPane('pane_7').style.zIndex = 492;
map.createPane('pane_8').style.zIndex = 491;
map.createPane('pane_10').style.zIndex = 489;

var baseMaps = {};
var overlayMaps = {};

// CAMADAS BASE
var googleSatellite = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
	maxZoom: 20,
	subdomains:['mt0','mt1','mt2','mt3'],
	attribution: '<a href="https://www.google.at/permissions/geoguidelines/attr-guide.html">Map data ©2021 Google</a>'
});
googleSatellite.addTo(map);
baseMaps['Google Satellite'] = googleSatellite;

// CAMADAS VETORIAIS
var _1__110_1497 = L.geoJSON(_1__110_1497_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_0'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(215, 25, 28, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 1- 110-1497</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['1__110_1497'] = _1__110_1497;

var _2_1497_2993_ = L.geoJSON(_2_1497_2993__data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_1'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(232, 91, 59, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 2-1497-2993 </h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['2_1497_2993_'] = _2_1497_2993_;

var _3__2993_5207 = L.geoJSON(_3__2993_5207_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_2'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(249, 157, 89, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 3- 2993-5207</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['3__2993_5207'] = _3__2993_5207;

var _4__5207_7154 = L.geoJSON(_4__5207_7154_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_3'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(254, 201, 128, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 4- 5207-7154</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['4__5207_7154'] = _4__5207_7154;

var _5__7154_9536 = L.geoJSON(_5__7154_9536_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_4'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(255, 237, 170, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 5- 7154-9536</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['5__7154_9536'] = _5__7154_9536;

var _6__9536_12578_ = L.geoJSON(_6__9536_12578__data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_5'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(236, 247, 185, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 6- 9536-12578 </h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['6__9536_12578_'] = _6__9536_12578_;

var _7__12578_14143 = L.geoJSON(_7__12578_14143_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_6'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(199, 232, 173, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 7- 12578-14143</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['7__12578_14143'] = _7__12578_14143;

var _8__14143_17712_ = L.geoJSON(_8__14143_17712__data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_7'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(157, 211, 166, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 8- 14143-17712 </h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['8__14143_17712_'] = _8__14143_17712_;

var _9__17712_34457 = L.geoJSON(_9__17712_34457_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_8'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(100, 171, 176, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 9- 17712-34457</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['9__17712_34457'] = _9__17712_34457;

var _10__34457_54997 = L.geoJSON(_10__34457_54997_data, {
			pointToLayer: function(geoJsonPoint, latlng) {return L.circleMarker(latlng, {pane: 'pane_10'})},
			style: {
						opacity: 1.0,
						fillOpacity: 1.0,
						radius: 2.0,
						weight: 0.0,
						color: 'rgba(35, 35, 35, 1.00)',
						fillColor: 'rgba(73, 148, 180, 1.00)'
			},
			onEachFeature: function (feature, layer){
				layer.on({click: clickedFeature});
				layer.bindPopup(function (layer) {
					return '<h4>CAMADA: 10- 34457-54997</h4><br/>'  +
							'<b>CALIBRATED:</b>&ensp;' + feature.properties['Calibrated'] + '<br/>' +
							'<b>COUNTRY:</b>&ensp;' + feature.properties['Country'] + '<br/>' +
							'<b>UNCAL:</b>&ensp;' + feature.properties['Uncal'] + '<br/>' +
							'<b>FID:</b>&ensp;' + feature.properties['fid'] + '<br/>' +
							'<b>LAT.:</b>&ensp;' + feature.properties['lat.'] + '<br/>' +
							'<b>LONG.:</b>&ensp;' + feature.properties['long.'] + '<br/>' +
							'<b>SIGMA:</b>&ensp;' + feature.properties['sigma'] + '<br/>' 
				});
			}
}).addTo(map);
overlayMaps['10__34457_54997'] = _10__34457_54997;

//Função que dá zoom sobre a feição clicada
function clickedFeature(e) {
	var feature = e.target;
	if (feature.feature.geometry.type == 'Point' ) {
		map.setView(feature.getLatLng(), 16);
	} else {
		map.fitBounds(feature.getBounds());
	}
}

// LEGENDA
var legend = L.control({position: 'bottomright'});
legend.onAdd = function (map) {
	var div = L.DomUtil.create('div', 'info legend');
	div.innerHTML = '<dl>';
	div.innerHTML += 	'<dt class="_1__110_1497_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(215, 25, 28, 1.00)"></svg>1- 110-1497</dt>';
	div.innerHTML += 	'<dt class="_2_1497_2993__lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(232, 91, 59, 1.00)"></svg>2-1497-2993 </dt>';
	div.innerHTML += 	'<dt class="_3__2993_5207_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(249, 157, 89, 1.00)"></svg>3- 2993-5207</dt>';
	div.innerHTML += 	'<dt class="_4__5207_7154_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(254, 201, 128, 1.00)"></svg>4- 5207-7154</dt>';
	div.innerHTML += 	'<dt class="_5__7154_9536_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(255, 237, 170, 1.00)"></svg>5- 7154-9536</dt>';
	div.innerHTML += 	'<dt class="_6__9536_12578__lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(236, 247, 185, 1.00)"></svg>6- 9536-12578 </dt>';
	div.innerHTML += 	'<dt class="_7__12578_14143_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(199, 232, 173, 1.00)"></svg>7- 12578-14143</dt>';
	div.innerHTML += 	'<dt class="_8__14143_17712__lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(157, 211, 166, 1.00)"></svg>8- 14143-17712 </dt>';
	div.innerHTML += 	'<dt class="_9__17712_34457_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(100, 171, 176, 1.00)"></svg>9- 17712-34457</dt>';
	div.innerHTML += 	'<dt class="_10__34457_54997_lgd"><svg class="legendIcon"><circle cx="9" cy="9" r="5" stroke="rgba(35, 35, 35, 1.00)" stroke-width="2" fill="rgba(73, 148, 180, 1.00)"></svg>10- 34457-54997</dt>';
	div.innerHTML += '</dl>';
	return div
}
legend.addTo(map);

//ESCALA
L.control.scale({
	maxWidth: 250,
	imperial: false
}).addTo(map);

// CONTROLE DE CAMADAS
L.control.layers(baseMaps, overlayMaps, {
	position: 'topright',
	collapsed: false,
	sortLayers: true
}).addTo(map);

function layerON (event){
	var className = event.name + '_lgd';
	var legendItems = document.getElementsByClassName(className);
	for (var i = 0; i < legendItems.length; i++) {
		legendItems[i].style.display = 'block';
	}
}

function layerOFF (event){
	var className = event.name + '_lgd';
	var legendItems = document.getElementsByClassName(className);
	for (var i = 0; i < legendItems.length; i++) {
		legendItems[i].style.display = 'none';
	}
}

map.on('overlayadd', layerON);
map.on('overlayremove', layerOFF);

// CALCULA A AREA QUE COBRE TODAS AS CAMADAS
var bounds = {xmin: 180, ymin: 90, xmax: -180, ymax: -90};
for (var layer in overlayMaps) {
	var layerBounds = overlayMaps[layer].getBounds();
	if (bounds.xmin > layerBounds.getSouthWest().lng) {bounds.xmin = layerBounds.getSouthWest().lng};
	if (bounds.ymin > layerBounds.getSouthWest().lat) {bounds.ymin = layerBounds.getSouthWest().lat};
	if (bounds.xmax < layerBounds.getNorthEast().lng) {bounds.xmax = layerBounds.getNorthEast().lng};
	if (bounds.ymax < layerBounds.getNorthEast().lat) {bounds.ymax = layerBounds.getNorthEast().lat};
}
map.fitBounds([
	[bounds.ymin, bounds.xmin],
	[bounds.ymax, bounds.xmax]
]);
