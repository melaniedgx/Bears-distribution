function filter(evt, column) {
	// Declare variables
	var input, filter, table, tr, td, i, txtValue;
	input = evt.target;
	filter = input.value.toUpperCase();
	table = evt.path[4];
	tr = table.getElementsByTagName("tr");

	// Loop through all table rows, and hide those who don't match the search query
	for (i = 2; i < tr.length; i++) {
		td = tr[i].getElementsByTagName("td")[column];
		if (td) {
			txtValue = td.textContent || td.innerText;
			if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			} else {
				tr[i].style.display = "none";
			}
		}
	}
}

function goToMap(layer, featureID){
	var feature = layer._layers[featureID];
	if (feature.feature.geometry.type == 'Point' ) {
		map.setView(feature.getLatLng(), 16);
	} else {
		map.fitBounds(feature.getBounds());
	}

	document.getElementById('mapBtn').click();
	feature.openPopup();

	if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
		layer.bringToFront();
	};
}

tableHTML__1__110_1497 = '<table id="_1__110_1497_table">';
tableHTML__1__110_1497 += 	'<tr>';
tableHTML__1__110_1497 += 		'<th>Mapa</th>';
tableHTML__1__110_1497 += 		'<th>Calibrated</th>';
tableHTML__1__110_1497 += 		'<th>Country</th>';
tableHTML__1__110_1497 += 		'<th>Uncal</th>';
tableHTML__1__110_1497 += 		'<th>fid</th>';
tableHTML__1__110_1497 += 		'<th>lat.</th>';
tableHTML__1__110_1497 += 		'<th>long.</th>';
tableHTML__1__110_1497 += 		'<th>sigma</th>';
tableHTML__1__110_1497 += 	'</tr>';
tableHTML__1__110_1497 += 	'<tr>';
tableHTML__1__110_1497 += 		'<td></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__1__110_1497 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__1__110_1497 += 	'</tr>';

var _1__110_1497_IDs = Object.keys(_1__110_1497._layers);
for (var i=0; i < _1__110_1497_IDs.length; i++){
	var feature = _1__110_1497._layers[_1__110_1497_IDs[i]].feature;
	tableHTML__1__110_1497 += '<tr>';
	tableHTML__1__110_1497 += 	'<td onclick="goToMap(_1__110_1497, ' + _1__110_1497_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__1__110_1497 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__1__110_1497 += '</tr>';
}

tableHTML__1__110_1497 += '</table>';
document.getElementById('_1__110_1497_tab').innerHTML = tableHTML__1__110_1497;

tableHTML__2_1497_2993_ = '<table id="_2_1497_2993__table">';
tableHTML__2_1497_2993_ += 	'<tr>';
tableHTML__2_1497_2993_ += 		'<th>Mapa</th>';
tableHTML__2_1497_2993_ += 		'<th>Calibrated</th>';
tableHTML__2_1497_2993_ += 		'<th>Country</th>';
tableHTML__2_1497_2993_ += 		'<th>Uncal</th>';
tableHTML__2_1497_2993_ += 		'<th>fid</th>';
tableHTML__2_1497_2993_ += 		'<th>lat.</th>';
tableHTML__2_1497_2993_ += 		'<th>long.</th>';
tableHTML__2_1497_2993_ += 		'<th>sigma</th>';
tableHTML__2_1497_2993_ += 	'</tr>';
tableHTML__2_1497_2993_ += 	'<tr>';
tableHTML__2_1497_2993_ += 		'<td></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__2_1497_2993_ += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__2_1497_2993_ += 	'</tr>';

var _2_1497_2993__IDs = Object.keys(_2_1497_2993_._layers);
for (var i=0; i < _2_1497_2993__IDs.length; i++){
	var feature = _2_1497_2993_._layers[_2_1497_2993__IDs[i]].feature;
	tableHTML__2_1497_2993_ += '<tr>';
	tableHTML__2_1497_2993_ += 	'<td onclick="goToMap(_2_1497_2993_, ' + _2_1497_2993__IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__2_1497_2993_ += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__2_1497_2993_ += '</tr>';
}

tableHTML__2_1497_2993_ += '</table>';
document.getElementById('_2_1497_2993__tab').innerHTML = tableHTML__2_1497_2993_;

tableHTML__3__2993_5207 = '<table id="_3__2993_5207_table">';
tableHTML__3__2993_5207 += 	'<tr>';
tableHTML__3__2993_5207 += 		'<th>Mapa</th>';
tableHTML__3__2993_5207 += 		'<th>Calibrated</th>';
tableHTML__3__2993_5207 += 		'<th>Country</th>';
tableHTML__3__2993_5207 += 		'<th>Uncal</th>';
tableHTML__3__2993_5207 += 		'<th>fid</th>';
tableHTML__3__2993_5207 += 		'<th>lat.</th>';
tableHTML__3__2993_5207 += 		'<th>long.</th>';
tableHTML__3__2993_5207 += 		'<th>sigma</th>';
tableHTML__3__2993_5207 += 	'</tr>';
tableHTML__3__2993_5207 += 	'<tr>';
tableHTML__3__2993_5207 += 		'<td></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__3__2993_5207 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__3__2993_5207 += 	'</tr>';

var _3__2993_5207_IDs = Object.keys(_3__2993_5207._layers);
for (var i=0; i < _3__2993_5207_IDs.length; i++){
	var feature = _3__2993_5207._layers[_3__2993_5207_IDs[i]].feature;
	tableHTML__3__2993_5207 += '<tr>';
	tableHTML__3__2993_5207 += 	'<td onclick="goToMap(_3__2993_5207, ' + _3__2993_5207_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__3__2993_5207 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__3__2993_5207 += '</tr>';
}

tableHTML__3__2993_5207 += '</table>';
document.getElementById('_3__2993_5207_tab').innerHTML = tableHTML__3__2993_5207;

tableHTML__4__5207_7154 = '<table id="_4__5207_7154_table">';
tableHTML__4__5207_7154 += 	'<tr>';
tableHTML__4__5207_7154 += 		'<th>Mapa</th>';
tableHTML__4__5207_7154 += 		'<th>Calibrated</th>';
tableHTML__4__5207_7154 += 		'<th>Country</th>';
tableHTML__4__5207_7154 += 		'<th>Uncal</th>';
tableHTML__4__5207_7154 += 		'<th>fid</th>';
tableHTML__4__5207_7154 += 		'<th>lat.</th>';
tableHTML__4__5207_7154 += 		'<th>long.</th>';
tableHTML__4__5207_7154 += 		'<th>sigma</th>';
tableHTML__4__5207_7154 += 	'</tr>';
tableHTML__4__5207_7154 += 	'<tr>';
tableHTML__4__5207_7154 += 		'<td></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__4__5207_7154 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__4__5207_7154 += 	'</tr>';

var _4__5207_7154_IDs = Object.keys(_4__5207_7154._layers);
for (var i=0; i < _4__5207_7154_IDs.length; i++){
	var feature = _4__5207_7154._layers[_4__5207_7154_IDs[i]].feature;
	tableHTML__4__5207_7154 += '<tr>';
	tableHTML__4__5207_7154 += 	'<td onclick="goToMap(_4__5207_7154, ' + _4__5207_7154_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__4__5207_7154 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__4__5207_7154 += '</tr>';
}

tableHTML__4__5207_7154 += '</table>';
document.getElementById('_4__5207_7154_tab').innerHTML = tableHTML__4__5207_7154;

tableHTML__5__7154_9536 = '<table id="_5__7154_9536_table">';
tableHTML__5__7154_9536 += 	'<tr>';
tableHTML__5__7154_9536 += 		'<th>Mapa</th>';
tableHTML__5__7154_9536 += 		'<th>Calibrated</th>';
tableHTML__5__7154_9536 += 		'<th>Country</th>';
tableHTML__5__7154_9536 += 		'<th>Uncal</th>';
tableHTML__5__7154_9536 += 		'<th>fid</th>';
tableHTML__5__7154_9536 += 		'<th>lat.</th>';
tableHTML__5__7154_9536 += 		'<th>long.</th>';
tableHTML__5__7154_9536 += 		'<th>sigma</th>';
tableHTML__5__7154_9536 += 	'</tr>';
tableHTML__5__7154_9536 += 	'<tr>';
tableHTML__5__7154_9536 += 		'<td></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__5__7154_9536 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__5__7154_9536 += 	'</tr>';

var _5__7154_9536_IDs = Object.keys(_5__7154_9536._layers);
for (var i=0; i < _5__7154_9536_IDs.length; i++){
	var feature = _5__7154_9536._layers[_5__7154_9536_IDs[i]].feature;
	tableHTML__5__7154_9536 += '<tr>';
	tableHTML__5__7154_9536 += 	'<td onclick="goToMap(_5__7154_9536, ' + _5__7154_9536_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__5__7154_9536 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__5__7154_9536 += '</tr>';
}

tableHTML__5__7154_9536 += '</table>';
document.getElementById('_5__7154_9536_tab').innerHTML = tableHTML__5__7154_9536;

tableHTML__6__9536_12578_ = '<table id="_6__9536_12578__table">';
tableHTML__6__9536_12578_ += 	'<tr>';
tableHTML__6__9536_12578_ += 		'<th>Mapa</th>';
tableHTML__6__9536_12578_ += 		'<th>Calibrated</th>';
tableHTML__6__9536_12578_ += 		'<th>Country</th>';
tableHTML__6__9536_12578_ += 		'<th>Uncal</th>';
tableHTML__6__9536_12578_ += 		'<th>fid</th>';
tableHTML__6__9536_12578_ += 		'<th>lat.</th>';
tableHTML__6__9536_12578_ += 		'<th>long.</th>';
tableHTML__6__9536_12578_ += 		'<th>sigma</th>';
tableHTML__6__9536_12578_ += 	'</tr>';
tableHTML__6__9536_12578_ += 	'<tr>';
tableHTML__6__9536_12578_ += 		'<td></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__6__9536_12578_ += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__6__9536_12578_ += 	'</tr>';

var _6__9536_12578__IDs = Object.keys(_6__9536_12578_._layers);
for (var i=0; i < _6__9536_12578__IDs.length; i++){
	var feature = _6__9536_12578_._layers[_6__9536_12578__IDs[i]].feature;
	tableHTML__6__9536_12578_ += '<tr>';
	tableHTML__6__9536_12578_ += 	'<td onclick="goToMap(_6__9536_12578_, ' + _6__9536_12578__IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__6__9536_12578_ += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__6__9536_12578_ += '</tr>';
}

tableHTML__6__9536_12578_ += '</table>';
document.getElementById('_6__9536_12578__tab').innerHTML = tableHTML__6__9536_12578_;

tableHTML__7__12578_14143 = '<table id="_7__12578_14143_table">';
tableHTML__7__12578_14143 += 	'<tr>';
tableHTML__7__12578_14143 += 		'<th>Mapa</th>';
tableHTML__7__12578_14143 += 		'<th>Calibrated</th>';
tableHTML__7__12578_14143 += 		'<th>Country</th>';
tableHTML__7__12578_14143 += 		'<th>Uncal</th>';
tableHTML__7__12578_14143 += 		'<th>fid</th>';
tableHTML__7__12578_14143 += 		'<th>lat.</th>';
tableHTML__7__12578_14143 += 		'<th>long.</th>';
tableHTML__7__12578_14143 += 		'<th>sigma</th>';
tableHTML__7__12578_14143 += 	'</tr>';
tableHTML__7__12578_14143 += 	'<tr>';
tableHTML__7__12578_14143 += 		'<td></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__7__12578_14143 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__7__12578_14143 += 	'</tr>';

var _7__12578_14143_IDs = Object.keys(_7__12578_14143._layers);
for (var i=0; i < _7__12578_14143_IDs.length; i++){
	var feature = _7__12578_14143._layers[_7__12578_14143_IDs[i]].feature;
	tableHTML__7__12578_14143 += '<tr>';
	tableHTML__7__12578_14143 += 	'<td onclick="goToMap(_7__12578_14143, ' + _7__12578_14143_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__7__12578_14143 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__7__12578_14143 += '</tr>';
}

tableHTML__7__12578_14143 += '</table>';
document.getElementById('_7__12578_14143_tab').innerHTML = tableHTML__7__12578_14143;

tableHTML__8__14143_17712_ = '<table id="_8__14143_17712__table">';
tableHTML__8__14143_17712_ += 	'<tr>';
tableHTML__8__14143_17712_ += 		'<th>Mapa</th>';
tableHTML__8__14143_17712_ += 		'<th>Calibrated</th>';
tableHTML__8__14143_17712_ += 		'<th>Country</th>';
tableHTML__8__14143_17712_ += 		'<th>Uncal</th>';
tableHTML__8__14143_17712_ += 		'<th>fid</th>';
tableHTML__8__14143_17712_ += 		'<th>lat.</th>';
tableHTML__8__14143_17712_ += 		'<th>long.</th>';
tableHTML__8__14143_17712_ += 		'<th>sigma</th>';
tableHTML__8__14143_17712_ += 	'</tr>';
tableHTML__8__14143_17712_ += 	'<tr>';
tableHTML__8__14143_17712_ += 		'<td></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__8__14143_17712_ += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__8__14143_17712_ += 	'</tr>';

var _8__14143_17712__IDs = Object.keys(_8__14143_17712_._layers);
for (var i=0; i < _8__14143_17712__IDs.length; i++){
	var feature = _8__14143_17712_._layers[_8__14143_17712__IDs[i]].feature;
	tableHTML__8__14143_17712_ += '<tr>';
	tableHTML__8__14143_17712_ += 	'<td onclick="goToMap(_8__14143_17712_, ' + _8__14143_17712__IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__8__14143_17712_ += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__8__14143_17712_ += '</tr>';
}

tableHTML__8__14143_17712_ += '</table>';
document.getElementById('_8__14143_17712__tab').innerHTML = tableHTML__8__14143_17712_;

tableHTML__9__17712_34457 = '<table id="_9__17712_34457_table">';
tableHTML__9__17712_34457 += 	'<tr>';
tableHTML__9__17712_34457 += 		'<th>Mapa</th>';
tableHTML__9__17712_34457 += 		'<th>Calibrated</th>';
tableHTML__9__17712_34457 += 		'<th>Country</th>';
tableHTML__9__17712_34457 += 		'<th>Uncal</th>';
tableHTML__9__17712_34457 += 		'<th>fid</th>';
tableHTML__9__17712_34457 += 		'<th>lat.</th>';
tableHTML__9__17712_34457 += 		'<th>long.</th>';
tableHTML__9__17712_34457 += 		'<th>sigma</th>';
tableHTML__9__17712_34457 += 	'</tr>';
tableHTML__9__17712_34457 += 	'<tr>';
tableHTML__9__17712_34457 += 		'<td></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__9__17712_34457 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__9__17712_34457 += 	'</tr>';

var _9__17712_34457_IDs = Object.keys(_9__17712_34457._layers);
for (var i=0; i < _9__17712_34457_IDs.length; i++){
	var feature = _9__17712_34457._layers[_9__17712_34457_IDs[i]].feature;
	tableHTML__9__17712_34457 += '<tr>';
	tableHTML__9__17712_34457 += 	'<td onclick="goToMap(_9__17712_34457, ' + _9__17712_34457_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__9__17712_34457 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__9__17712_34457 += '</tr>';
}

tableHTML__9__17712_34457 += '</table>';
document.getElementById('_9__17712_34457_tab').innerHTML = tableHTML__9__17712_34457;

tableHTML__10__34457_54997 = '<table id="_10__34457_54997_table">';
tableHTML__10__34457_54997 += 	'<tr>';
tableHTML__10__34457_54997 += 		'<th>Mapa</th>';
tableHTML__10__34457_54997 += 		'<th>Calibrated</th>';
tableHTML__10__34457_54997 += 		'<th>Country</th>';
tableHTML__10__34457_54997 += 		'<th>Uncal</th>';
tableHTML__10__34457_54997 += 		'<th>fid</th>';
tableHTML__10__34457_54997 += 		'<th>lat.</th>';
tableHTML__10__34457_54997 += 		'<th>long.</th>';
tableHTML__10__34457_54997 += 		'<th>sigma</th>';
tableHTML__10__34457_54997 += 	'</tr>';
tableHTML__10__34457_54997 += 	'<tr>';
tableHTML__10__34457_54997 += 		'<td></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 1)" placeholder="Procurar Calibrated"></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 2)" placeholder="Procurar Country"></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 3)" placeholder="Procurar Uncal"></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 4)" placeholder="Procurar fid"></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 5)" placeholder="Procurar lat."></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 6)" placeholder="Procurar long."></td>';
tableHTML__10__34457_54997 += 		'<td><input type="text" onkeyup="filter(event, 7)" placeholder="Procurar sigma"></td>';
tableHTML__10__34457_54997 += 	'</tr>';

var _10__34457_54997_IDs = Object.keys(_10__34457_54997._layers);
for (var i=0; i < _10__34457_54997_IDs.length; i++){
	var feature = _10__34457_54997._layers[_10__34457_54997_IDs[i]].feature;
	tableHTML__10__34457_54997 += '<tr>';
	tableHTML__10__34457_54997 += 	'<td onclick="goToMap(_10__34457_54997, ' + _10__34457_54997_IDs[i] + ')"><img src="javascript/icon.png" width="32px" height="32px"/></td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['Calibrated'] + '</td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['Country'] + '</td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['Uncal'] + '</td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['fid'] + '</td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['lat.'] + '</td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['long.'] + '</td>';
	tableHTML__10__34457_54997 += 	'<td>' + feature.properties['sigma'] + '</td>';
	tableHTML__10__34457_54997 += '</tr>';
}

tableHTML__10__34457_54997 += '</table>';
document.getElementById('_10__34457_54997_tab').innerHTML = tableHTML__10__34457_54997;

